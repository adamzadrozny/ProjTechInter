﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutomateMyWork.Models
{
    public class UserService
    {
        public int UserServiceID { get; set; }
        public int UserID { get; set; }
        public int ServiceID { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutomateMyWork.Models
{
    public class State
    {
        public int ID { get; set; }
        public string NazwaWojewodztwa { get; set; }


        //public ICollection<User> Users { get; set; }
    }
}

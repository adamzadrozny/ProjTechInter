﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutomateMyWork.Models
{
    public class User
    {
        public int ID { get; set; }
        public string NazwaFirmy { get; set; }
        public int Wojewodztwo { get; set; }
        public string Miasto { get; set; }
        public string KodPocztowy { get; set; }
        public string Ulica { get; set; }
        public int NrDomu { get; set; }
        public int NrMieszkania { get; set; }
        public string Mail { get; set; }
        public string Password { get; set; }
        public string Role { get; set; } 

        //public ICollection<UserService> UserServices { get; set; }
        //public ICollection<State> States { get; set; }
    }
}

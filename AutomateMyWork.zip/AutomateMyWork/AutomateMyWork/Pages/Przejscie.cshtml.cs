﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AutomateMyWork.Data;
using AutomateMyWork.Models;
using System.Security.Principal;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace AutomateMyWork
{
    public class PrzejscieModel : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;
        

        public PrzejscieModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }
         public string Mail { get; set; }
        public User User { get; set; }
        //public var userId { get; set; }
        /*public void Controller(IHttpContextAccessor httpContextAccessor)
        {
            var userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            Mail = HttpContext.User.Identity.Name;//User.ID=_context.Users.Select(x=>x.)
        }*/
        public IActionResult OnGet()
        {
            //var claimsIdentity = (ClaimsIdentity)this.User.Identity;
            Mail = HttpContext.User.Identity.Name;
            int id = _context.Users.Where(m => m.Mail == Mail).Select(x => x.ID).First();

            return RedirectToPage("/Users/Details", new { id = id });
        }
    }
}
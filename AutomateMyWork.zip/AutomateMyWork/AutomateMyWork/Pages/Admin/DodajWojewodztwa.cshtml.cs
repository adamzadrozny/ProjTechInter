﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using AutomateMyWork.Data;
using AutomateMyWork.Models;
using Microsoft.AspNetCore.Authorization;

namespace AutomateMyWork
{
    [Authorize(Roles="Admin")]
    public class DodajWojewodztwaModel : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;

        public DodajWojewodztwaModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public State State { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            /*if (_context.States.First()==null)
            {
                State.ID = 0;
            }
            else
            {
                State.ID = _context.States.OrderByDescending(i => i.ID).FirstOrDefault()+1;
            }
            */

            _context.States.Add(State);
            await _context.SaveChangesAsync();

            return RedirectToPage("./DodajWojewodztwa");
        }
    }
}

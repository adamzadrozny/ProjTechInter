﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using AutomateMyWork.Data;
using AutomateMyWork.Models;
using Microsoft.Extensions.Options;

namespace AutomateMyWork
{
    public class CreateModel : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;
        
        public SelectList Options { get; set; }
        [BindProperty]
        public User User { get; set; }
        [BindProperty]
        public State State { get; set; }
        public CreateModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {

            Options = new SelectList(_context.States, nameof(State.ID), nameof(State.NazwaWojewodztwa));
            //Options = new SelectList(_context.States, Convert.ToString(State.ID),State.NazwaWojewodztwa);

            return Page();
        }

        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            
            User.Wojewodztwo = State.ID;
            User.Role = "Client";// Options.State.ID;//Convert.ToInt32(Options.SelectedValue);
            _context.Users.Add(User);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Users/Login");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using AutomateMyWork.Models;

namespace AutomateMyWork
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        [Required]
        [Display(Name = "Adres email")]
        public string Mail { get; set; }

        [BindProperty]
        [Required]
        [Display(Name = "Hasło")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public bool RememberMe { get; set; }
        [BindProperty]
        public User User { get; set; }
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;
        //[BindProperty]
        //public List<SelectListItem> Options { get; set; }

        public LoginModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            {
                //User log;
                //int id = 0;
                //string haslo = null;
                
                try
                {
                    User = _context.Users.Where(m => m.Mail == Mail).First();
                }
                catch (Exception)
                {
                    User = null;
                    ModelState.AddModelError("", "Niepoprawny login!");
                }


                if (User.Mail != Mail)
                {
                    ModelState.AddModelError("", "Niepoprawny login!");
                    return Page();
                    //log = _context.Users.Where(m => m.Mail == Mail).First();
                    //id = log.ID;
                    //haslo = log.Password;
                }
                if (User.Password!= Password)
                {
                    ModelState.AddModelError("", "Niepoprawne hasło!");
                    return Page();
                }
                //else
                //{
                //    ModelState.AddModelError("", "Niepoprawny login lub hasło!");
                //    return Page();
                //}

                /*
                var isValid = log!=null; 
                if (!isValid)
                {
                    ModelState.AddModelError("", "username or password is invalid");
                    return Page();
                }*/

                // Create the identity from the user info
                var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme, ClaimTypes.Email, ClaimTypes.Role);
                //identity.AddClaim(new Claim(ClaimTypes., Mail));
                identity.AddClaim(new Claim(ClaimTypes.Email, User.Mail));
                // You can add roles to use role-based authorization
                identity.AddClaim(new Claim(ClaimTypes.Role, User.Role));

                // Authenticate using the identity
                var principal = new ClaimsPrincipal(identity);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties { IsPersistent = RememberMe });

                /*string pageName = $"/Users/Details?ID={id}";
                return base.RedirectToPage(pageName);///Details", new { id = log.ID });*/
                return RedirectToPage("/Users/Details", new { id = User.ID });
            }
            else
            {
                ModelState.AddModelError("", "Proszę wpisać swój adres email i hasło!");
                return Page();
            }
            
        }
        public async Task<IActionResult> OnPostLogoutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToPage("/Index");
        }

    }
}
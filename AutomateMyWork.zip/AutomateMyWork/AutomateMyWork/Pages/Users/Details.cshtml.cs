﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AutomateMyWork.Data;
using AutomateMyWork.Models;

namespace AutomateMyWork
{
    public class DetailsModel : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;

        public DetailsModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public User User { get; set; }
        public IList <int> ServiceId { get; set; }
        public IList<Service> Services { get; set; }

        public string Wojew;
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                
            }

            User = await _context.Users.FirstOrDefaultAsync(m => m.ID == id);
            Wojew = await _context.States.Where(m => m.ID == User.Wojewodztwo).Select(n => n.NazwaWojewodztwa).FirstAsync();
            ServiceId = await _context.UserServices.Where(m => m.UserID == id).Select(n => n.ServiceID).ToListAsync();
            Services = await _context.Services.ToListAsync();
            
            if (User == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}

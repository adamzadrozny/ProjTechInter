﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AutomateMyWork.Data;
using AutomateMyWork.Models;

namespace AutomateMyWork
{
    public class EditModel : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;

        public EditModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        [BindProperty]
        public User User { get; set; }
        [BindProperty]
        public State State { get; set; }
        public SelectList Options { get; set; }
        public string rola;
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            User = await _context.Users.FirstOrDefaultAsync(m => m.ID == id);
            rola = User.Role;

            if (User == null)
            {
                return NotFound();
            }
            Options = new SelectList(_context.States, nameof(State.ID), nameof(State.NazwaWojewodztwa));
            return Page();
        }

        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            User.Wojewodztwo = State.ID;
            User.Role = "Client";
            _context.Attach(User).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(User.ID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("/Users/Details", new { id = User.ID });
        }

        private bool UserExists(int id)
        {
            return _context.Users.Any(e => e.ID == id);
        }
    }
}

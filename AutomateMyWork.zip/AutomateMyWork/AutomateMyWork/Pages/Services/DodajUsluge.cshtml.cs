﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutomateMyWork.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AutomateMyWork
{
    public class DodajUslugeModel : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;

        public DodajUslugeModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {

            return Page();
        }

        [BindProperty]
        public Service Service { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
           
            _context.Services.Add(Service);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Services/Index");
        }
    }
}
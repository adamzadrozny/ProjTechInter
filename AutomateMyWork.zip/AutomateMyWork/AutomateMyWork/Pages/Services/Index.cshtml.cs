﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AutomateMyWork.Data;
using AutomateMyWork.Models;

namespace AutomateMyWork
{
    public class IndexModelServices : PageModel
    {
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;

        public IndexModelServices(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public IList<Service> Service { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {

            Service = await _context.Services.ToListAsync();

            if (Service == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}

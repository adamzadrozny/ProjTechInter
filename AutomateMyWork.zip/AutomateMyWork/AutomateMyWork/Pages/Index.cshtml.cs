﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutomateMyWork.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace AutomateMyWork.Pages
{
   
    public class IndexModel : PageModel
    {
        /*private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }*/
        private readonly AutomateMyWork.Data.AutomateMyWorkContext _context;

        public IndexModel(AutomateMyWork.Data.AutomateMyWorkContext context)
        {
            _context = context;
        }

        public User User { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return Page(); //NotFound();
            }
            else
            {
                User = await _context.Users.FirstOrDefaultAsync(m => m.ID == id);
            }


            //if (User == null)
            //{
            //    return NotFound();
            //}
            return Page();
        }
    }
}

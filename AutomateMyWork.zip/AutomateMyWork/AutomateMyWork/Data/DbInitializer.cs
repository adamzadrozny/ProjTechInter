﻿using System;
using AutomateMyWork.Data;
using AutomateMyWork.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AutomateMyWork.Data
{
    public class DbInitializer
    {
        public static void Initialize(AutomateMyWorkContext context)
        {
            context.Database.EnsureCreated();

            // 
            if (context.Users.Any())
            {
                return;   // DB has been seeded
            }

            var users = new User[]
            {
                new User{NazwaFirmy="AMW",Wojewodztwo=7,Miasto="Warszawa",KodPocztowy="00-020",
                    Ulica="Emilii Plater",NrDomu=14,NrMieszkania=20,Mail="amw@amw.pl",Password="Admin",Role="Admin"},
                new User{NazwaFirmy="BBB",Wojewodztwo=15,Miasto="Poznań",KodPocztowy="60-020",
                    Ulica="Warszawska",NrDomu=5,NrMieszkania=10,Mail="biuro@bbb.pl",Password="Haslo123",Role="Client"},
                new User{NazwaFirmy="AAA",Wojewodztwo=9,Miasto="Lublin",KodPocztowy="20-057",
                    Ulica="Piłsudskiego",NrDomu=7,NrMieszkania=4,Mail="biuro@aaa.pl",Password="HasloAAA",Role="Client"},
                new User{NazwaFirmy="ABC",Wojewodztwo=10,NrMieszkania=15,Miasto="Białystok",KodPocztowy="15-080",
                    Ulica="Morska",NrDomu=3,Mail="biuro@ABC.pl",Password="Haslo123",Role="Client"}
            };

            foreach (User s in users)
            {
                context.Users.Add(s);
            }
            context.SaveChanges();

            var services = new Service[]
            {
                new Service{NazwaUslugi="Level 1",Opis="Automatyzacja procesów w aplikacjach MS Office, " +
                    " takich jak tworzenie raportów w Excel za pomocą VBA, rozsyłanie maili z treścią wygenerowaną w Word/Excel."},
                new Service{NazwaUslugi="Level 2",Opis="Zaawansowane raportowanie z wykorzystaniem technologii ETL i BI."},
                new Service{NazwaUslugi="Level 3",Opis="Automatyzacja procesów sprzedażowych. Wyszukiwanie potencjalnych klientów " +
                "na dany produkt poprzez algorytm klastrowania, mailing, badanie zadowolenia z usług."},
                new Service{NazwaUslugi="Level 4",Opis="Chatboty."},
                new Service{NazwaUslugi="Level 5",Opis="Indywidualne usługi oparte o rozwiązania AI."},
            };
            foreach (Service c in services)
            {
                context.Services.Add(c);
            }
            context.SaveChanges();

            var userservices = new UserService[]
            {
                new UserService{ServiceID=1,UserID=2},
                new UserService{ServiceID=3,UserID=2},
                new UserService{ServiceID=1,UserID=3},
                new UserService{ServiceID=2,UserID=3},
                new UserService{ServiceID=5,UserID=3},
                new UserService{ServiceID=1,UserID=1},
                new UserService{ServiceID=2,UserID=1},
                new UserService{ServiceID=3,UserID=1},
                new UserService{ServiceID=4,UserID=1},
                new UserService{ServiceID=5,UserID=1},
                new UserService{ServiceID=3,UserID=4},
                new UserService{ServiceID=5,UserID=4},

            };
            foreach (UserService e in userservices)
            {
                context.UserServices.Add(e);
            }
            context.SaveChanges();

            var states = new State[]
            {
                new State { NazwaWojewodztwa = "dolnośląskie"},
                new State { NazwaWojewodztwa = "kujawsko - pomorskie"},
                new State { NazwaWojewodztwa = "lubelskie" },
                new State { NazwaWojewodztwa = "lubuskie" },
                new State { NazwaWojewodztwa = "łódzkie" },
                new State { NazwaWojewodztwa = "małopolskie" },
                new State { NazwaWojewodztwa = "mazowieckie" },
                new State { NazwaWojewodztwa = "opolskie" },
                new State { NazwaWojewodztwa = "podkarpackie" },
                new State { NazwaWojewodztwa = "podlaskie" },
                new State { NazwaWojewodztwa = "pomorskie" },
                new State { NazwaWojewodztwa = "śląskie" },
                new State { NazwaWojewodztwa = "świętokrzyskie" },
                new State { NazwaWojewodztwa = "warmińsko - mazurskie" },
                new State { NazwaWojewodztwa = "wielkopolskie" },
                new State { NazwaWojewodztwa = "zachodniopomorskie" }
            };
            foreach (State g in states.OrderBy(x=>x.NazwaWojewodztwa))
            {
                context.States.Add(g);
            }
            context.SaveChanges();
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AutomateMyWork.Models;

namespace AutomateMyWork.Data
{
    public class AutomateMyWorkContext : DbContext
    {
        public AutomateMyWorkContext(DbContextOptions<AutomateMyWorkContext> options)
            : base(options)
        {
        }

        public DbSet<AutomateMyWork.Models.User> Users { get; set; }
        public DbSet<AutomateMyWork.Models.Service> Services { get; set; }
        public DbSet<AutomateMyWork.Models.UserService> UserServices { get; set; }
        public DbSet<AutomateMyWork.Models.State> States { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().ToTable("User");
            modelBuilder.Entity<Service>().ToTable("Service");
            modelBuilder.Entity<UserService>().ToTable("UserService");
            modelBuilder.Entity<State>().ToTable("State");


        }
    }
}
